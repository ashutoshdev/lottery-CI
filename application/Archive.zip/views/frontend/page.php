<div class="about_sec">
      <div class="container">
        <h4><?php echo $page->title; ?></h4>
        <div class="about_body">
        <p><?= $page->description; ?></p>
        </div>
      </div>
    </div>
